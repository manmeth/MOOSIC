# Moosic — Security Testing Evidence

This file documents the testing evidence for the **8 security components** implemented for the Moosic digital business system.

Each section contains:
1. **What was tested**
2. **What the test proves**
3. **The screenshot evidence**

> **Important:** The screenshots are stored in the same GitHub folder as this Markdown file. Do not rename or move the image files unless you also update the image names below.

---

## 1. Authentication

### What was tested
The authentication system was tested for:
- Successful user registration
- Successful login
- Access to the protected `/me` endpoint
- Login with invalid credentials
- Access to `/me` without authentication

### Expected security behaviour
- Valid authentication should return **HTTP 200**.
- Invalid credentials should return **HTTP 401**.
- A protected endpoint accessed without a token should return **HTTP 401**.

### Evidence

**Successful registration and login — HTTP 200**

![Authentication success](01_authentication_success.png)

**Invalid email/password — HTTP 401**

![Invalid login](01_authentication_invalid_login.png)

**Unauthenticated `/me` request — HTTP 401**

![Unauthenticated request](01_authentication_unauthenticated.png)

### Result
**PASS** — Authentication and protected endpoint access behaved as expected.

---

## 2. Authorization

### What was tested
The authorization system was tested using two normal users and a manager account.

The test checked:
- User A accessing User A's own resources
- User A attempting to access User B's resources
- A request with no authentication token
- User B attempting to access User A's resources
- Manager accessing a manager-only endpoint
- Normal user attempting to access a manager-only endpoint

### Expected security behaviour
- Own resources → **HTTP 200**
- Cross-user access → **HTTP 403**
- No token → **HTTP 401**
- Manager-only endpoint for manager → **HTTP 200**
- Manager-only endpoint for normal user → **HTTP 403**

### Evidence

![Authorization testing](02_authorization.png)

The screenshot shows:
- User A own resources: **200**
- User A accessing User B resources: **403**
- No token: **401**
- User B accessing User A resources: **403**
- Manager access to manager-only endpoint: **200**
- Normal user access to manager-only endpoint: **403**

### Result
**PASS** — User ownership and role-based access controls correctly prevented unauthorized access.

---

## 3. Data Protection

### What was tested
The password/data protection implementation was tested to verify that:
- Login still works with the stored password hash.
- `/me` does not expose a password field.
- `/me` does not expose a password hash.
- The stored password value is not equal to the original plaintext password.

The database inspection also shows that the stored password is a bcrypt-style hash rather than plaintext.

### Expected security behaviour
Sensitive password information should not be returned by the API, and passwords should not be stored as plaintext.

### Evidence

![Data protection testing](03_data_protection.png)

The screenshot shows:
- Login status: **200**
- `/me` status: **200**
- Password field exposed by `/me`: **False**
- Password hash exposed by `/me`: **False**
- Stored password equals plaintext: **False**

### Result
**PASS** — Password storage and API exposure checks passed.

---

## 4. Network Security — CORS

### What was tested
The CORS configuration was tested using a preflight request.

The test checked:
- CORS preflight response
- `Allow-Origin` header
- `Allow-Methods` header
- `Allow-Headers` header

### Expected security behaviour
The backend should correctly respond to an approved CORS preflight request with the required CORS headers.

### Evidence

![CORS testing](04_network_security_cors.png)

The screenshot shows:
- CORS preflight status: **200**
- Allow-Origin header present: **True**
- Allow-Methods header present: **True**
- Allow-Headers header present: **True**

### Result
**PASS** — The configured CORS policy responded correctly to the preflight test.

> The team's firewall/network-level implementation is a separate assigned component. This evidence documents the CORS testing performed for the application.

---

## 5. Database Security

### What was tested
The database security test checked whether user-specific database resources were protected by authenticated ownership controls.

The test created two users and checked:
- User A can access User A's own data.
- User A cannot access User B's data.

### Expected security behaviour
- Own data → **HTTP 200**
- Cross-user data → **HTTP 403**

### Evidence

![Database security testing](05_database_security.png)

The screenshot shows:
- Database users created: **2**
- User A own data access: **200**
- User A cross-user data access: **403**
- Database ownership protection: **True**

### Result
**PASS** — User-specific database access was protected by ownership authorization checks.

---

## 6. Backup and Recovery

### What was tested
A disposable SQLite database was used to test:
- Backup creation
- Simulated database failure
- Database restoration
- Recovery of a test record

### Expected security behaviour
The database should be recoverable from a valid backup after a simulated failure.

### Evidence

![Backup and recovery testing](06_backup_recovery.png)

The screenshot shows:
- Backup created: **True**
- Database failure simulated: **True**
- Database restored: **True**
- Recovered test record: **True**
- Recovery test: **PASS**

### Result
**PASS** — The backup and recovery procedure successfully restored the test database and recovered its record.

---

## 7. Monitoring and Logging

### What was tested
Security-relevant application events were tested using HTTP status codes for:
- Successful login
- Failed login
- Unauthenticated access
- Cross-user unauthorized access

### Expected security behaviour
The application should produce distinguishable results for successful, failed, unauthenticated, and unauthorized requests.

### Evidence

![Monitoring and logging testing](07_monitoring_logging.png)

The screenshot shows:
- Successful login status: **200**
- Failed login status: **401**
- Unauthenticated `/me` status: **401**
- Cross-user access status: **403**
- Security events verified: **4**

### Result
**PASS** — Four security-relevant events were successfully verified through their expected HTTP status codes.

---

## 8. Account and Password Protection

### What was tested
The password protection controls were tested using:
- A weak password during registration
- A valid password during registration
- An incorrect password during login

### Expected security behaviour
- Weak password → **HTTP 422**
- Valid password → **HTTP 200**
- Wrong password → **HTTP 401**

### Evidence

![Account and password protection testing](08_account_password_protection.png)

The screenshot shows:
- Weak password registration status: **422**
- Valid password registration status: **200**
- Wrong password login status: **401**
- Password protection test: **PASS**

### Result
**PASS** — Weak passwords were rejected and incorrect passwords could not authenticate.

---

# Overall Security Testing Summary

| # | Security Component | Result |
|---|---|---|
| 1 | Authentication | **PASS** |
| 2 | Authorization | **PASS** |
| 3 | Data Protection | **PASS** |
| 4 | Network Security — CORS | **PASS** |
| 5 | Database Security | **PASS** |
| 6 | Backup & Recovery | **PASS** |
| 7 | Monitoring & Logging | **PASS** |
| 8 | Account & Password Protection | **PASS** |

## Conclusion

All **8 security components** were tested using the evidence shown above. The screenshots provide supporting proof of the implemented security controls and their expected test results.
